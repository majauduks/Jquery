$(".submitting").click("click", function () {
  $("button").after("<h1></h1>");
  $("h1").text(`Hello there ${$(".input-tochange").val()}`);
});
