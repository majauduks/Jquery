$("button").click("click", function () {
  $("button").after("<h1></h1>");
  let color = $(".color").val();
  let text = $(".tekst").val();
  $("h1").css("color", color);
  $("h1").text(text);
});
